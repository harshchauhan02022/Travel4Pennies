#Travel$Pennies

This is a simple user registration API bulit with Node.js, Express, and Sequelize.

##Features
- User registration with bcrypt password hashing.
- Email uniqueness validation.
- Sequelize ORM for MySQL.
- Environment variables support using dotenv.
- Modular folder structure (MVC pattern).


##Folder Structure
