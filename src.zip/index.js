const express = require('express');
const session = require('express-session');
const passport = require('passport');
const app = express();
const cors = require("cors");
require('dotenv').config();
const sequelize = require('./src/config/db');

const userRoutes = require('./src/components/routes/user.Routes');
const authRoutes = require('./src/components/routes/auth.Routes');
const adminRoutes = require('./src/components/routes/admin.Routes')
const flightRoutes = require("./src/components/routes/flight.routes");
const hotelRoutes = require('./src/components/routes/hotels.Routes')
const airportRoutes = require("./src/components/routes/airport.routes");
const carRoutes = require('./src/components/routes/car.Routes');
const amadeusRoutes = require('./src/components/Amadeus/AmadeusRotes')

require('./src/config/passport');


app.use(cors({
    origin: "http://localhost:5173",
    credentials: true
}));
app.use(express.json());

app.use(session({
    secret: process.env.SESSION_SECRET || 'default_secret_key',
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

app.use('/api', adminRoutes);
app.use('/api', userRoutes);
app.use('/auth', authRoutes);
app.use("/api/kayak", flightRoutes);
app.use("/api", hotelRoutes);
app.use("/api/airports", airportRoutes);
app.use('/api', carRoutes);
app.use('/', amadeusRoutes);

app.get("/", (req, res) => {
    res.json([{ id: 1, name: "Harsh" }]);
});

const PORT = process.env.PORT || 5000;

sequelize.sync().then(() => {
    app.listen(PORT, () => {
        console.log(`🚀 Server running on port ${PORT}`);
        console.log("✅ Database connected successfully!");
    });
}).catch((err) => {
    console.error("❌ Failed to sync database:", err.message);
});
